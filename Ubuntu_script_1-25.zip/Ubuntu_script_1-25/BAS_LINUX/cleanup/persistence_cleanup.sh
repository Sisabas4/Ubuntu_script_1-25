#!/bin/bash

# Unified Cleanup Script for all 10 SISA Persistence Tests

# Define output folder for cleanup logs
output_folder="./Linux_output/Cleanup"
mkdir -p "$output_folder"
output_file="$output_folder/Cleanup_Log.txt"

# Function to log messages
log() {
    echo "$1" | tee -a "$output_file"
}

log "Starting cleanup for all SISA persistence tests..."

# Cleanup for T1543.002 (Systemd Service)
log "Cleaning up SISA Test #1 (Systemd Service - T1543.002)..."
systemctl stop sisa-systemd-service.service
systemctl disable sisa-systemd-service.service
rm -rf /etc/systemd/system/sisa-systemd-service.service
systemctl daemon-reload

# Cleanup for T1543.002 (SysV Init Service)
log "Cleaning up SISA Test #2 (SysV Init Service - T1543.002)..."
if [ -f /etc/rc.subr ]; then
    service sisa-test stop
    service sisa-test disable
    rm -f /etc/init.d/sisa-test
fi

# Cleanup for T1053.003 (Cron Job Persistence)
log "Cleaning up SISA Test #3 (Cron Job - T1053.003)..."
crontab -l | grep -v "SISA cron job" | crontab -

# Cleanup for T1053.006 (Systemd Timer)
log "Cleaning up SISA Test #4 (Systemd Timer - T1053.006)..."
systemctl stop sisa-timer.timer
systemctl disable sisa-timer.timer
rm -f /etc/systemd/system/sisa-timer.timer
systemctl daemon-reload

# Cleanup for T1546.004 (Profile modifications)
log "Cleaning up SISA Test #5 (Profile modifications - T1546.004)..."
sed -i "/# SISA was here... T1546.004/d" ~/.bash_profile
sed -i "/# SISA was here... T1546.004/d" ~/.bashrc
sed -i "/# SISA was here... T1546.004/d" ~/.shrc
sudo sed -i "/# Hello from SISA T1546.004/d" /etc/profile
sudo sed -i "/# SISA was here... T1546.004/d" /etc/profile.d/bash_completion.sh
sudo userdel -fr art

# Cleanup for T1053.002 (at jobs)
log "Cleaning up SISA Test #6 (at jobs - T1053.002)..."
atq | awk '{print $1}' | xargs atrm

# Cleanup for T1053.003 (Cron Job for Persistence)
log "Cleaning up SISA Test #7 (Cron Job for Persistence - T1053.003)..."
crontab -l | grep -v "SISA persistence cron job" | crontab -

# Cleanup for T1547.001 (rc.common and rc.local modifications)
log "Cleaning up SISA Test #8 (rc.common and rc.local modifications - T1547.001)..."
sudo sed -i "/# SISA T1547.001 entry/d" /etc/rc.common
sudo sed -i "/# SISA T1547.001 entry/d" /etc/rc.local

# Cleanup for T1574.006 (Shared Library Injection via /etc/ld.so.preload)
log "Cleaning up SISA Test #9 (Shared Library Injection - T1574.006)..."
sudo sed -i "s#/home/username/Linux_output/Persistence/T1574.006_Persistence/T1574006.so##" /etc/ld.so.preload

# Cleanup for T1547.006 (GRUB Persistence)
log "Cleaning up SISA Test #10 (GRUB Persistence - T1547.006)..."
sudo sed -i "/# SISA GRUB Persistence/d" /etc/default/grub
sudo update-grub

log "All SISA tests cleaned up successfully."

# End of cleanup script
