#!/bin/bash

# Set the program URL and the target paths
program_url="https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1040/src/linux_pcapdemo.c"
program_name="linux_pcapdemo"
program_c_file="/tmp/${program_name}.c"
program_executable="/tmp/${program_name}"
log_dir="Linux_output/Credential_access"
log_file="${log_dir}/T1040_pc_Credential_access.txt"

# Function to install dependencies on Debian-based systems
install_dependencies_debian() {
    echo "Installing curl, gcc, and libpcap-dev on Debian-based system..."
    sudo apt-get update
    sudo apt-get install -y curl gcc libpcap-dev
}

# Function to install dependencies on Red Hat-based systems
install_dependencies_redhat() {
    echo "Installing curl, gcc, and libpcap-devel on Red Hat-based system..."
    sudo yum install -y curl gcc libpcap-devel
}

# Function to redirect output to log file
redirect_output() {
    exec > >(tee -a "$log_file") 2>&1
}

# Create the log directory if it does not exist
mkdir -p "$log_dir"

# Redirecting output to both terminal and log file
redirect_output

# Check if curl is installed, if not, install it
if ! command -v curl &> /dev/null; then
    echo "curl is not installed. Attempting to install it..."
    if command -v apt-get &> /dev/null; then
        install_dependencies_debian
    elif command -v yum &> /dev/null; then
        install_dependencies_redhat
    else
        echo "Package manager not supported. Please install curl manually."
        exit 1
    fi
fi

# Check if gcc is installed, if not, install it
if ! command -v gcc &> /dev/null; then
    echo "gcc is not installed. Attempting to install it..."
    if command -v apt-get &> /dev/null; then
        install_dependencies_debian
    elif command -v yum &> /dev/null; then
        install_dependencies_redhat
    else
        echo "Package manager not supported. Please install gcc manually."
        exit 1
    fi
fi

# Check if libpcap is installed, if not, install it
if ! ldconfig -p | grep -q libpcap; then
    echo "libpcap is not installed. Attempting to install it..."
    if command -v apt-get &> /dev/null; then
        install_dependencies_debian
    elif command -v yum &> /dev/null; then
        install_dependencies_redhat
    else
        echo "Package manager not supported. Please install libpcap manually."
        exit 1
    fi
fi

# Verify that libpcap is installed
if ! ldconfig -p | grep -q libpcap; then
    echo "Failed to install libpcap. Please check your package manager and repositories."
    exit 1
fi

# Step 1: Download the program
echo "Downloading the program from GitHub..."
curl -L $program_url -o $program_c_file
if [[ $? -ne 0 ]]; then
    echo "Failed to download the program."
    exit 1
fi
echo "Program downloaded to ${program_c_file}"

# Step 2: Compile the C program
echo "Compiling the program..."
gcc $program_c_file -o $program_executable -lpcap
if [[ $? -ne 0 ]]; then
    echo "Failed to compile the program."
    exit 1
fi
echo "Program compiled to ${program_executable}"

# Step 3: Run the executable with the specified command
echo "Running the program..."
sudo $program_executable -a -t 3
if [[ $? -ne 0 ]]; then
    echo "Failed to run the program."
    exit 1
fi
echo "Program executed successfully."

# Cleanup the downloaded and compiled files if needed
# Uncomment the following lines to delete the files after execution
# echo "Cleaning up..."
# rm -f $program_c_file $program_executable
# echo "Cleanup completed."

# Provide feedback on log file location
echo "Results saved in: $log_file"
