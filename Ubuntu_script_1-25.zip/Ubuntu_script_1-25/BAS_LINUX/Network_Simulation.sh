#!/bin/bash

# Set the base output directory and subdirectory
BASE_OUTPUT_DIR="./Linux_output"
SUB_DIR="Network_Simulation"
OUTPUT_FILE="Network_Simulation_output.txt"

# Create the base output directory if it doesn't exist
if [ ! -d "$BASE_OUTPUT_DIR" ]; then
    mkdir -p "$BASE_OUTPUT_DIR"
fi

# Create the subdirectory if it doesn't exist
if [ ! -d "$BASE_OUTPUT_DIR/$SUB_DIR" ]; then
    mkdir -p "$BASE_OUTPUT_DIR/$SUB_DIR"
fi

# Set the full path to the output file
OUTPUT_PATH="$BASE_OUTPUT_DIR/$SUB_DIR/$OUTPUT_FILE"

# Function to log output
log_output() {
    local message="$1"
    echo "$message" | tee -a "$OUTPUT_PATH"
}

# Example command to install a tool (e.g., flightsim) and log the output
log_output "Installing flightsim..."
if ! command -v flightsim &> /dev/null; then
    go install github.com/alphasoc/flightsim/v2@latest 2>&1 | tee -a "$OUTPUT_PATH"
    log_output "flightsim installed successfully."
else
    log_output "flightsim is already installed."
fi

# Example commands to run flightsim and log the output
log_output "Running flightsim commands..."
flightsim --help 2>&1 | tee -a "$OUTPUT_PATH"
flightsim run 2>&1 | tee -a "$OUTPUT_PATH"
flightsim run c2 2>&1 | tee -a "$OUTPUT_PATH"
flightsim run dga 2>&1 | tee -a "$OUTPUT_PATH"
flightsim run ssh-transfer:1GB 2>&1 | tee -a "$OUTPUT_PATH"
flightsim get families:c2 2>&1 | tee -a "$OUTPUT_PATH"

log_output "All commands executed. Output saved to $OUTPUT_PATH."

