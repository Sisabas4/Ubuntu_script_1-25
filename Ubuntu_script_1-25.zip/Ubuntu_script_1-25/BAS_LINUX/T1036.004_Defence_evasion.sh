#!/bin/bash

# Ensure the output directory exists
output_dir="./Linux_output/Defence_Evasion"
mkdir -p "$output_dir"

# Output file
output_file="$output_dir/T1036.004_Defence_evasion.txt"

# SISA Test #3 - Rename /proc/pid/comm using prctl
# This test runs a C program that calls prctl(PR_SET_NAME) to modify /proc/pid/comm value to "totally_legit".

exe_path="/tmp/T1036_004_prctl_rename"
c_file_path="/tmp/prctl_rename.c"

# Create the C program
cat << 'EOF' > "$c_file_path"
#include <stdio.h>
#include <sys/prctl.h>
#include <unistd.h>

int main() {
    prctl(PR_SET_NAME, "totally_legit", 0, 0, 0);
    while (1) {
        sleep(10);
    }
    return 0;
}
EOF

# Compile the C program
cc -o "$exe_path" "$c_file_path"

# Run the executable in the background
"$exe_path" &

# Give it a moment to start
sleep 1

# Check if the process name has been changed
TMP=$(ps | grep totally_legit)

if [ -z "$TMP" ]; then
    echo "Renamed process NOT FOUND in process list" | tee -a "$output_file"
    exit 1
else
    echo "Renamed process FOUND in process list" | tee -a "$output_file"
    echo "$TMP" | tee -a "$output_file"
fi

# Cleanup
rm -f "$exe_path" "$c_file_path"
echo "Cleanup done. All chosen SISA tests executed." | tee -a "$output_file"
exit 0
